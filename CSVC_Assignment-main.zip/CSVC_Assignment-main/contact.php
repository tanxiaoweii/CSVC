<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Nana Cafe</title>

<meta name="keywords" />

<meta name="description" />

<link href="style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {
	font-size: 16px;
	font-weight: bold;
}
-->
</style>
</head>
<body>
<div id="container">
  <div id="header_section"> </div>
  <div id="menu_bg">
    <div id="menu">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="aboutus.php">About Us</a></li>
		<li><a href="contact.php"  class="current">Contact Us</a></li>
        <li><a href="loginindex.php">Order Now! </a></li>
        <li><a href="admin_index.php">Admin</a></li>
      </ul>
    </div>
  </div>
  <div id="header_pizza"> </div>
  <div id="content">
    <div id="content_left">
      <div class="text" style="color:#000000">
	    <br />
			    <div align="center" class="style1">Contact Information</div><br>
		<div align="justify">
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<p><strong>Phone: 22458770</strong><br><br><strong>Email Address: info@nanacafe.net</strong><br></p>.<br />
		</div>
    </div>
  </div>
  

 
</div>
<div id="container_end"> </div>
</div>
<div id="footer">
    	<div class="top"></div>
        <div class="middle">
    Copyright © Nana Cafe2024</div>
        <div class="button"></div>
</div>
</div>
</body>

</html>